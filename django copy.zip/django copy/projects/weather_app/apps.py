from django.apps import AppConfig


class WeatherAppConfig(AppConfig):
    name = 'weather_app'
